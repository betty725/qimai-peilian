"""Loopback-only server for the bundled pet. No recording/upload endpoints."""
import http.server,sys,os,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(root),**kw)
 def log_message(self,*a):pass
 def end_headers(self):
  self.send_header('Cache-Control','no-cache')
  self.send_header('Cross-Origin-Resource-Policy','same-origin')
  super().end_headers()
server=http.server.ThreadingHTTPServer(('127.0.0.1',8973),Handler)
Path(sys.argv[1]).write_text(str(server.server_address[1]))
server.serve_forever()
